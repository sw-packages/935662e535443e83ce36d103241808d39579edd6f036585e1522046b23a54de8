/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#define AWS_SDK_VERSION_STRING "1.9.218"
#define AWS_SDK_VERSION_MAJOR 1
#define AWS_SDK_VERSION_MINOR 9
#define AWS_SDK_VERSION_PATCH 218
